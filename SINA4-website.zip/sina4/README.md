# SINA4+ — Global AI Health

A complete English-only, multi-page Astro marketing website for Sina Health Technology FZ-LLC. Dark navy, teal and silver visual identity; a session-only cinematic intro; a lazy-loaded Three.js Earth; fictional clinical-note demonstration; and a server-validated organizational demo request endpoint.

## Run locally

Use Node.js 22 LTS and npm.

```sh
npm ci
cp .env.example .env
npm run dev
```

Open http://localhost:4321. Public pages work without environment values. The demo form is deliberately disabled without a public Turnstile key; the endpoint returns an unavailable response without its required private configuration. No submission is claimed as received until the configured receiver returns success.

```sh
npm test
npm run build
```

The build runs Astro/TypeScript checks, prerenders marketing routes, and creates `.vercel/output` with static assets plus the `/api/demo` serverless function. `dist/client` alone is not a complete production deployment: it does not include a working demo endpoint. For a production-equivalent local Vercel environment, use `vercel dev`. Astro's generic `preview` command is retained but Vercel adapter preview support may be limited.

## Deploy to Vercel

1. Put this folder in a Git repository and import it into your Vercel account. Select the Astro framework; use `npm run build`. Keep Vercel's output-directory default. Select Node.js 22.
2. Set `SITE_URL` to your real HTTPS origin (no path). This determines canonical URLs, Open Graph URLs, robots and sitemap links. The default `.example` origin is intentionally a placeholder.
3. Create a Cloudflare Turnstile widget for the real domain and any approved Vercel preview hostname. Set the environment variables below. Do not use Turnstile's public test keys in production.
4. Configure an HTTPS demo-request receiver that authenticates the bearer secret, validates input, durably stores each lead before acknowledging it, and treats `Idempotency-Key` as an idempotency key. A CRM workflow or owned server endpoint can implement this contract. No particular CRM is assumed.
5. Complete the legal/company placeholders and operational privacy details. Verify the final provider list, retention period, subprocessors, locations, and any legal basis required for your operations. No certification or compliance status is claimed.
6. Deploy, add your domain in Vercel, and apply the DNS records Vercel supplies. HTTPS is managed by Vercel.
7. Run a production-domain Turnstile and delivery check with a fictional inquiry. Confirm the receiver stored the lead, and that a failed receiver never produces a success message. Verify the geographic block using a genuine Turkish request path on Vercel. Do not expose an untrusted origin server that accepts spoofable Vercel headers.

This delivery does not include a live Vercel deployment, account credentials, production Turnstile keys, a configured CRM/lead store, or finalized legal text. These account-specific items must be supplied by the operator. No patient data belongs in the website form.

### Environment variables

| Variable | Visibility | Purpose |
| --- | --- | --- |
| `SITE_URL` | Build | Real public HTTPS origin |
| `PUBLIC_TURNSTILE_SITE_KEY` | Public/build | Turnstile site key; changing it requires rebuilding |
| `TURNSTILE_SECRET_KEY` | Server | Turnstile verification secret |
| `TURNSTILE_HOSTNAMES` | Server | Comma-separated exact allowed challenge hostnames |
| `DEMO_WEBHOOK_URL` | Server | HTTPS lead receiver |
| `DEMO_WEBHOOK_SECRET` | Server | Bearer credential for the receiver |

Environment changes should be followed by a redeployment. Never commit `.env` or real secrets. Example values are in `.env.example`.

### Receiver payload

```json
{
  "id": "generated-uuid",
  "createdAt": "ISO-8601 timestamp",
  "name": "Alex Example",
  "email": "alex@hospital.example",
  "organization": "Example Hospital",
  "country": "GB",
  "role": "Clinical lead",
  "message": "Fictional workflow inquiry.",
  "privacyConsent": true,
  "consentVersion": "2026-09-29",
  "source": "sina4-marketing"
}
```

The receiver gets `Authorization: Bearer …` and `Idempotency-Key: <id>`. A 2xx response means the request was accepted for durable handling. Network uncertainty can still produce a user retry; the receiving organization should deduplicate equivalent inquiries appropriately. The website logs no submitted payloads.

## Page structure

- `/`: Home, intro, Earth, data flow, fictional interactive example, solutions and trust.
- `/product`: overview; `/product/data-collection`, `/analysis`, `/summarization`, `/clinical-notes-intelligence`, `/integrations` under that prefix.
- `/solutions`: overview; hospitals, clinics, research.
- `/security`: overview; data-residency, privacy-compliance, responsible-ai.
- `/resources`: overview; blog, FAQ, and two complete editorial articles.
- `/about`: overview; company and team (no invented people or credentials).
- `/request-a-demo`, `/privacy-policy`, `/terms`, `/cookie-policy`, and a custom 404.

Every navigation item has a page. Disclosure buttons open mega menus; the main labels still navigate. The mobile menu uses a modal dialog with native focus containment and Escape support. Content links and utility controls are not competing marketing CTAs; all conversion buttons say “Request a Demo.”

## Source map

```text
src/
  components/    Shared header, footer, logo, closing CTA, example widget
  data/          Navigation and route-specific editorial content
  layouts/       HTML document, SEO, View Transitions and global imports
  lib/           Shared input validation and independently testable endpoint logic
  pages/         Home, static route generator, legal pages, form, API and robots
  scripts/       Navigation, GSAP, Lenis, intro, Three.js and form handling
  styles/        Tailwind import, design tokens and responsive styles
public/
  images/        Local optimized brand crops and Earth textures
  favicon.svg
 tests/          Server behavior tests
```

## Motion and performance

- Intro is session-only (`sessionStorage`), has a visible Skip control, Escape support, and a 3.9-second hard stop independent of WebGL loading. If JavaScript is disabled, the intro never blocks content.
- Reduced motion skips the intro, smooth scrolling, reveal animations and the WebGL load; the supplied Earth crop remains visible.
- Three.js is dynamically imported on Home only. The Earth uses a modest mesh, a capped pixel ratio, and a throttled decorative render loop; it suspends rendering offscreen and in hidden tabs. This targets smooth interaction without spending the entire mobile frame budget on decorative rendering.
- WebGL failure retains a static fallback. Page swaps clean up timelines, scroll triggers, observers, event handlers, and GPU resources.
- Desktop data-flow artwork is pinned within the story. Small screens use a natural document flow. Text blocks reveal without splitting semantic headings into inaccessible fragments.
- Fonts and imagery are local. No analytics or advertising tags are included.
- Lighthouse 90+ and 60fps are targets, not measured guarantees. Verify on the actual domain and target devices, with production headers and real third-party configuration.

## Demo protection

The endpoint checks the Vercel-supplied country header before processing the body. `TR` yields HTTP 403 and exactly: `SINA4+ is not currently available in your region.` Public pages have no region block. The form country list excludes Turkey, and the server uses the same allowlist.

Client and server reject common personal email providers and `.tr` domains. This is a domain policy, not proof of corporate ownership; organizational approval is still required. Server validation also checks field types/lengths, a 16 KB streaming body limit, consent, origin, honeypot, and Turnstile token length. Verification requires the expected Turnstile action `demo` and an allowed hostname. Tokens are verified only server-side. Requests fail closed when secrets or the lead receiver are absent.

Add any organization-specific rate limiting with Vercel Firewall before enabling public traffic. The application does not pretend that an in-memory counter is a durable distributed rate limiter. The country restriction is based on Vercel's IP-derived country metadata; it cannot establish citizenship or defeat every VPN/proxy.

## Brand and asset notes

The supplied SINA4+ logo board is retained as optimized crops for the symbol, mountain horizon, fallback Earth and social preview. These are raster brand assets; replace with approved original vector masters when available. The crop preserves the supplied mark rather than inventing a different logo.

Earth textures: Three.js examples, `examples/textures/planets/earth_atmos_2048.jpg` and `earth_lights_2048.png`, retrieved from the Three.js repository. Source: https://github.com/mrdoob/three.js/tree/master/examples/textures/planets . Three.js license: https://github.com/mrdoob/three.js/blob/master/LICENSE . Manrope is distributed by `@fontsource/manrope` under its included font license. Review brand-image and third-party asset rights for your final launch.

## Verification

`npm test` covers region rejection, email policy, country tampering, missing consent, honeypot, origin, body limit, unavailable configuration, challenge hostname/action, successful delivery, and delivery failure. These tests use mocked external services, never real demo requests. Browser validation findings are recorded in `QA.md`.
