import { defineConfig } from 'astro/config';
import vercel from '@astrojs/vercel';
import sitemap from '@astrojs/sitemap';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({site:process.env.SITE_URL || 'https://sina4.example',adapter:vercel(),integrations:[sitemap()],vite:{plugins:[tailwindcss()]},prefetch:{prefetchAll:false,defaultStrategy:'hover'}});
