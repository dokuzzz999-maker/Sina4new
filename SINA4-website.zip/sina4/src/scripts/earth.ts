import * as THREE from 'three';
export function createEarth(host:HTMLElement, reduced:boolean){
 let renderer:THREE.WebGLRenderer;
 try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:window.innerWidth>800,powerPreference:'low-power'});}catch{return ()=>{};}
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));host.appendChild(renderer.domElement);
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(34,1,.1,100);camera.position.z=4.3;
 const loader=new THREE.TextureLoader();let disposed=false,loaded=0; const fallback=host.parentElement?.querySelector<HTMLElement>('.earth-fallback'); const ready=()=>{if(disposed)return;loaded++;if(loaded===2&&fallback){fallback.style.opacity='0';host.style.opacity='1';}draw();};host.style.opacity='0'; const failure=()=>{if(fallback)fallback.style.opacity='.8';host.style.opacity='0';};
 const day=loader.load('/images/earth-day.jpg',ready,undefined,failure);day.colorSpace=THREE.SRGBColorSpace;
 const night=loader.load('/images/earth-night.png',ready,undefined,failure);night.colorSpace=THREE.SRGBColorSpace;
 const geo=new THREE.SphereGeometry(1.22,64,40);
 const mat=new THREE.MeshPhongMaterial({map:day,color:0x325264,emissiveMap:night,emissive:0xffdcb0,emissiveIntensity:1.4,shininess:9});
 const globe=new THREE.Mesh(geo,mat);globe.rotation.set(.12,-1.7,-.18);scene.add(globe);
 scene.add(new THREE.AmbientLight(0x1c5369,.4));const sun=new THREE.DirectionalLight(0xb9f2ff,2);sun.position.set(-3,3,1);scene.add(sun);
 const atmosphereGeo=new THREE.SphereGeometry(1.255,48,32);
 const atmosphereMat=new THREE.ShaderMaterial({transparent:true,side:THREE.BackSide,blending:THREE.AdditiveBlending,depthWrite:false,vertexShader:'varying vec3 vNormal; varying vec3 vPosition; void main(){vNormal=normalize(normalMatrix*normal);vec4 p=modelViewMatrix*vec4(position,1.0);vPosition=p.xyz;gl_Position=projectionMatrix*p;}',fragmentShader:'varying vec3 vNormal;varying vec3 vPosition;void main(){float rim=pow(1.0-abs(dot(normalize(vNormal),normalize(-vPosition))),3.5);gl_FragColor=vec4(0.1,0.65,0.85,rim*0.85);}'});
 scene.add(new THREE.Mesh(atmosphereGeo,atmosphereMat));
 function draw(){renderer.render(scene,camera);}
 const resize=()=>{if(disposed)return;const {width,height}=host.getBoundingClientRect();renderer.setSize(width,height);camera.aspect=width/Math.max(height,1);camera.updateProjectionMatrix();draw();};
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 const lost=(event:Event)=>{event.preventDefault();failure();};renderer.domElement.addEventListener('webglcontextlost',lost);
 let visible=true,frame=0,last=0;const start=performance.now();
 const io=new IntersectionObserver(([e])=>{visible=e.isIntersecting;});io.observe(host);
 function tick(now:number){if(disposed)return;frame=requestAnimationFrame(tick);if(!visible||document.hidden||now-last<15)return;const dt=Math.min((now-last)/1000,.05);last=now;globe.rotation.y+=dt*.022;camera.position.z=4.3+Math.max(0,1-(now-start)/3000)*.7;draw();}
 if(!reduced)frame=requestAnimationFrame(tick);
 return ()=>{disposed=true;cancelAnimationFrame(frame);observer.disconnect();io.disconnect();geo.dispose();mat.dispose();day.dispose();night.dispose();atmosphereGeo.dispose();atmosphereMat.dispose();renderer.domElement.removeEventListener('webglcontextlost',lost);renderer.dispose();renderer.forceContextLoss();host.replaceChildren();};
}
