import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import {corporateEmailError} from '../lib/validation';
gsap.registerPlugin(ScrollTrigger);
let dispose=()=>{};
function setup(){
 dispose();const controller=new AbortController(),signal=controller.signal;const cleanups:Array<()=>void>=[];let alive=true;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const on=(el:EventTarget|null,event:string,cb:EventListener)=>el?.addEventListener(event,cb,{signal});
 const groups=[...document.querySelectorAll<HTMLElement>('.nav-group')];
 function closeMenus(){groups.forEach(g=>{g.classList.remove('open');g.querySelector('button')?.setAttribute('aria-expanded','false');g.querySelector<HTMLElement>('.mega')!.inert=true;});}
 groups.forEach(g=>{const button=g.querySelector('button')!;on(button,'click',()=>{const open=g.classList.contains('open');closeMenus();if(!open){g.classList.add('open');button.setAttribute('aria-expanded','true');g.querySelector<HTMLElement>('.mega')!.inert=false;}});on(g,'focusout',e=>{if(!g.contains((e as FocusEvent).relatedTarget as Node))closeMenus();});});
 on(document,'click',e=>{if(!(e.target as Element).closest('.nav-group'))closeMenus();});
 on(document,'keydown',e=>{if((e as KeyboardEvent).key==='Escape'){const active=groups.find(g=>g.classList.contains('open'));closeMenus();active?.querySelector('button')?.focus();}});
 const menu=document.querySelector<HTMLDialogElement>('#mobile-menu'),toggle=document.querySelector('.mobile-toggle');
 const closeMobile=()=>{menu?.close();document.body.style.overflow='';toggle?.setAttribute('aria-expanded','false');};
 on(toggle,'click',()=>{menu?.showModal();document.body.style.overflow='hidden';toggle?.setAttribute('aria-expanded','true');});on(document.querySelector('.mobile-close'),'click',closeMobile);on(menu,'close',()=>{document.body.style.overflow='';toggle?.setAttribute('aria-expanded','false');});on(menu,'click',e=>{if((e.target as Element).closest('a'))closeMobile();});
 const summaryButton=document.querySelector<HTMLButtonElement>('#summarize');on(summaryButton,'click',()=>{const result=document.querySelector<HTMLElement>('#summary-result')!,idle=document.querySelector<HTMLElement>('#summary-idle')!;const showing=!result.hidden;result.hidden=showing;idle.hidden=!showing;summaryButton!.innerHTML=showing?'Show structured summary <span aria-hidden="true">＋</span>':'Reset example <span aria-hidden="true">↺</span>';if(!reduced&&!showing)gsap.fromTo(result,{opacity:0,y:8},{opacity:1,y:0,duration:.45});});
 const context=gsap.context(()=>{if(reduced)return;
 gsap.utils.toArray<HTMLElement>('.section-heading,.solution-card,.trust-list article,.prose section').forEach(el=>gsap.from(el,{y:25,opacity:0,duration:.65,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 90%',once:true}}));
 if(innerWidth>800&&document.querySelector('.flow-visual')){ScrollTrigger.create({trigger:'.flow-layout',start:'top 15%',end:'bottom 80%',pin:'.flow-visual',pinSpacing:false});gsap.to('.earth-stage',{y:80,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:1}});}
 });
 cleanups.push(()=>context.revert());
 if(!reduced&&matchMedia('(pointer:fine)').matches){const lenis=new Lenis({duration:1.05,smoothWheel:true,anchors:true});const raf=(t:number)=>lenis.raf(t*1000);gsap.ticker.add(raf);lenis.on('scroll',ScrollTrigger.update);cleanups.push(()=>{gsap.ticker.remove(raf);lenis.destroy();});
 const glow=document.querySelector<HTMLElement>('.cursor-glow');on(document,'pointermove',e=>{const p=e as PointerEvent;if(glow)glow.style.transform=`translate(${p.clientX-180}px,${p.clientY-180}px)`;});document.querySelectorAll<HTMLElement>('.magnetic').forEach(el=>{on(el,'pointermove',e=>{const p=e as PointerEvent,r=el.getBoundingClientRect();gsap.to(el,{x:(p.clientX-r.left-r.width/2)*.12,y:(p.clientY-r.top-r.height/2)*.2,duration:.3});});on(el,'pointerleave',()=>{gsap.to(el,{x:0,y:0,duration:.3});});});}
 // Intro is independent of WebGL loading and always exits within four seconds.
 const intro=document.querySelector<HTMLElement>('#intro');let seen=false;try{seen=sessionStorage.getItem('sina4-intro')==='1';}catch{}
 if(intro&&!reduced&&!seen){intro.hidden=false;try{sessionStorage.setItem('sina4-intro','1');}catch{}
 const prior=document.activeElement as HTMLElement;const skip=intro.querySelector<HTMLButtonElement>('button')!;skip.focus({preventScroll:true});
 const finish=()=>{intro.hidden=true;if(document.activeElement===skip)prior?.focus({preventScroll:true});};
 on(skip,'click',finish);on(document,'keydown',e=>{if(intro.hidden)return;if((e as KeyboardEvent).key==='Escape')finish();if((e as KeyboardEvent).key==='Tab'){e.preventDefault();skip.focus();}});
 const tl=gsap.timeline();tl.fromTo('.intro-lockup',{opacity:0,scale:.75},{opacity:1,scale:1,duration:1.2,delay:.5}).fromTo('.intro-word',{opacity:0,letterSpacing:'.7em'},{opacity:1,letterSpacing:'.15em',duration:.7},1.2).to(intro,{backgroundColor:'rgba(3,13,22,0)',duration:.6},2.6).to('.intro-lockup',{opacity:0,scale:.5,duration:.65},2.8).to(intro,{opacity:0,duration:.3,onComplete:finish},3.45);const timeout=setTimeout(finish,3900);cleanups.push(()=>{clearTimeout(timeout);tl.kill();});
 const canvas=document.querySelector<HTMLCanvasElement>('#intro-particles')!,ctx=canvas.getContext('2d');let frame=0;const started=performance.now();const w=canvas.width=innerWidth,h=canvas.height=innerHeight;
 const particles=Array.from({length:180},(_,i)=>{const t=i/179;return {x:Math.random()*w,y:Math.random()*h,tx:w/2+Math.sin(t*Math.PI*2)*65,ty:h/2-130+t*210};});
 const paint=(now:number)=>{if(!ctx||intro.hidden)return;ctx.clearRect(0,0,w,h);const t=Math.min(1,(now-started)/1250);ctx.fillStyle='#14d1c1';ctx.globalAlpha=1-Math.max(0,(now-started-1200)/700);particles.forEach(p=>{ctx.beginPath();ctx.arc(p.x+(p.tx-p.x)*t,p.y+(p.ty-p.y)*t,1.3,0,Math.PI*2);ctx.fill();});frame=requestAnimationFrame(paint);};frame=requestAnimationFrame(paint);cleanups.push(()=>cancelAnimationFrame(frame));
 }
 const earth=document.querySelector<HTMLElement>('#earth-canvas');if(earth&&!reduced){import('./earth').then(({createEarth})=>{if(alive)cleanups.push(createEarth(earth,reduced));}).catch(()=>{});}
 const form=document.querySelector<HTMLFormElement>('#demo-form');if(form){const email=form.querySelector<HTMLInputElement>('[name=email]')!;on(email,'input',()=>email.setCustomValidity(corporateEmailError(email.value)||''));on(form,'submit',async e=>{e.preventDefault();const status=document.querySelector<HTMLElement>('#form-status')!,button=form.querySelector<HTMLButtonElement>('[type=submit]')!;if(!form.reportValidity())return;button.disabled=true;status.classList.remove('error');status.textContent='Sending your request…';try{const data=new FormData(form);const response=await fetch('/api/demo',{method:'POST',body:JSON.stringify(Object.fromEntries(data)),headers:{'Content-Type':'application/json'},signal});const result=await response.json();if(!response.ok)throw new Error(result.message||'Your request could not be sent. Please try again.');status.textContent=result.message;form.reset();}catch(error){if(signal.aborted)return;status.classList.add('error');status.textContent=error instanceof Error?error.message:'Your request could not be sent. Please try again.';}finally{button.disabled=false;const turnstile=(window as any).turnstile;turnstile?.reset();}});
 const holder=document.querySelector<HTMLElement>('#turnstile');if(holder?.dataset.sitekey){let widget:string|undefined;const render=()=>{if(!alive)return;const turnstile=(window as any).turnstile;if(turnstile)widget=turnstile.render(holder,{sitekey:holder.dataset.sitekey,action:'demo',theme:'dark'});};if((window as any).turnstile)render();else{const script=document.createElement('script');script.src='https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';script.async=true;script.onload=render;document.head.appendChild(script);cleanups.push(()=>script.remove());}cleanups.push(()=>{if(widget)(window as any).turnstile?.remove(widget);});}}
 dispose=()=>{alive=false;controller.abort();closeMobile();cleanups.forEach(fn=>fn());};
}
document.addEventListener('astro:page-load',setup);
document.addEventListener('astro:before-swap',()=>dispose());
