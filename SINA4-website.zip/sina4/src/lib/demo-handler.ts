import {validateDemo} from './validation';
export interface DemoConfig {siteUrl?:string;secret?:string;hostnames?:string;webhook?:string;webhookSecret?:string}
const json=(message:string,status:number)=>new Response(JSON.stringify({message}),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
async function readBounded(request:Request){const reader=request.body?.getReader();if(!reader)throw new Error('empty');let length=0;const chunks:Uint8Array[]=[];while(true){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>16384){await reader.cancel();throw new Error('large');}chunks.push(value);}const bytes=new Uint8Array(length);let at=0;for(const c of chunks){bytes.set(c,at);at+=c.length;}return JSON.parse(new TextDecoder().decode(bytes));}
export async function handleDemo(request:Request,config:DemoConfig,fetcher:typeof fetch=fetch):Promise<Response>{
 // Trust this header only behind Vercel, which supplies/overwrites geolocation metadata.
 if(request.headers.get('x-vercel-ip-country')?.trim().toUpperCase()==='TR')return json('SINA4+ is not currently available in your region.',403);
 if(request.method!=='POST')return new Response(null,{status:405,headers:{Allow:'POST','Cache-Control':'no-store'}});
 if(!request.headers.get('content-type')?.startsWith('application/json'))return json('Unsupported request format.',415);
 const origin=request.headers.get('origin');
 if(!origin||origin!==new URL(request.url).origin)return json('Unable to verify the request origin.',403);
 let data:Record<string,string>;try{data=await readBounded(request);}catch{return json('The request is invalid or too large.',400);}
 const error=validateDemo(data);if(error)return json(error,400);
 if(!config.secret||!config.hostnames||!config.webhook||!config.webhookSecret)return json('Demo requests are temporarily unavailable. Please try again later.',503);
 let destination:URL;try{destination=new URL(config.webhook);if(destination.protocol!=='https:')throw new Error();}catch{return json('Demo requests are temporarily unavailable. Please try again later.',503);}
 try{
 const verification=await fetcher('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({secret:config.secret,response:data['cf-turnstile-response']}),signal:AbortSignal.timeout(8000)});
 if(!verification.ok)return json('Security verification is unavailable. Please try again.',503);
 const checked=await verification.json();
 if(checked.success!==true||checked.action!=='demo'||!config.hostnames.split(',').map(h=>h.trim()).includes(checked.hostname))return json('Security verification failed. Please try again.',400);
 const id=crypto.randomUUID();
 const lead={id,createdAt:new Date().toISOString(),name:data.name.trim(),email:data.email.trim().toLowerCase(),organization:data.organization.trim(),country:data.country,role:data.role.trim(),message:data.message.trim(),privacyConsent:true,consentVersion:'2026-09-29',source:'sina4-marketing'};
 // The receiver must durably store the lead before returning 2xx. Never log the payload.
 const delivered=await fetcher(destination,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${config.webhookSecret}`,'Idempotency-Key':id},body:JSON.stringify(lead),signal:AbortSignal.timeout(10000),redirect:'error'});
 if(!delivered.ok)return json('Your request could not be delivered. Please try again later.',502);
 return json('Thank you. Your demo request has been received. Our team will review your organization’s requirements.',200);
 }catch{return json('Your request could not be completed. Please try again later.',503);}
}
