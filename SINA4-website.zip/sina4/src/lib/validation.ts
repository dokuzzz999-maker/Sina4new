export const countries=[['AU','Australia'],['AT','Austria'],['BH','Bahrain'],['BE','Belgium'],['CA','Canada'],['HR','Croatia'],['CY','Cyprus'],['CZ','Czechia'],['DK','Denmark'],['EE','Estonia'],['FI','Finland'],['FR','France'],['DE','Germany'],['GR','Greece'],['HK','Hong Kong'],['IS','Iceland'],['IE','Ireland'],['IL','Israel'],['IT','Italy'],['JP','Japan'],['KW','Kuwait'],['LV','Latvia'],['LI','Liechtenstein'],['LT','Lithuania'],['LU','Luxembourg'],['MT','Malta'],['MC','Monaco'],['NL','Netherlands'],['NZ','New Zealand'],['NO','Norway'],['OM','Oman'],['PL','Poland'],['PT','Portugal'],['QA','Qatar'],['RO','Romania'],['SA','Saudi Arabia'],['SG','Singapore'],['SK','Slovakia'],['SI','Slovenia'],['KR','South Korea'],['ES','Spain'],['SE','Sweden'],['CH','Switzerland'],['TW','Taiwan'],['AE','United Arab Emirates'],['GB','United Kingdom'],['US','United States']] as const;
export function corporateEmailError(email:string):string|null{
 const trimmed=email.trim().toLowerCase();
 if(!/^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/i.test(trimmed)||trimmed.length>254)return 'Enter a valid corporate email address.';
 const domain=trimmed.split('@')[1];
 if(domain==='tr'||domain.endsWith('.tr'))return 'Email addresses ending in .tr are not accepted.';
 const personal=/^(gmail|googlemail|hotmail|yahoo|ymail|outlook|live|msn|aol|icloud|me|mail|gmx|proton|protonmail|yandex|tutanota|fastmail)\./;
 if(personal.test(domain))return 'Please use your corporate email address, not a personal email provider.';
 return null;
}
export function validateDemo(input:unknown):string|null{
 if(!input||typeof input!=='object'||Array.isArray(input))return 'Invalid request.';
 const d=input as Record<string,unknown>;
 for(const [key,max] of [['name',120],['email',254],['organization',200],['country',2],['role',120],['message',3000]] as const){if(typeof d[key]!=='string'||!(d[key] as string).trim()||(d[key] as string).length>max)return `Please provide a valid ${key}.`;}
 const email=corporateEmailError(d.email as string);if(email)return email;
 if(!countries.some(([code])=>code===d.country))return 'Select an available country.';
 if(d.consent!=='on')return 'Please provide privacy consent.';
 if(d.website)return 'Unable to process this request.';
 if(typeof d['cf-turnstile-response']!=='string'||!d['cf-turnstile-response']||d['cf-turnstile-response'].length>2048)return 'Complete the security verification and try again.';
 return null;
}
