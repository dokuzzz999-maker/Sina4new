export const navigation = [
 {label:'Product',href:'/product',items:[['Data Collection','/product/data-collection'],['Analysis','/product/analysis'],['Summarization','/product/summarization'],['Clinical Notes Intelligence','/product/clinical-notes-intelligence'],['Integrations','/product/integrations']]},
 {label:'Solutions',href:'/solutions',items:[['Hospitals','/solutions/hospitals'],['Clinics','/solutions/clinics'],['Research','/solutions/research']]},
 {label:'Security',href:'/security',items:[['Data Residency','/security/data-residency'],['Privacy & Compliance','/security/privacy-compliance'],['Responsible AI','/security/responsible-ai']]},
 {label:'Resources',href:'/resources',items:[['Blog','/resources/blog'],['FAQ','/resources/faq']]},
 {label:'About',href:'/about',items:[['Company','/about/company'],['Team','/about/team']]}
];
