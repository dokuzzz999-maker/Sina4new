import type {APIRoute} from 'astro';
import {handleDemo} from '../../lib/demo-handler';
export const prerender=false;
export const ALL:APIRoute=({request})=>handleDemo(request,{siteUrl:import.meta.env.SITE_URL,secret:import.meta.env.TURNSTILE_SECRET_KEY,hostnames:import.meta.env.TURNSTILE_HOSTNAMES,webhook:import.meta.env.DEMO_WEBHOOK_URL,webhookSecret:import.meta.env.DEMO_WEBHOOK_SECRET});
