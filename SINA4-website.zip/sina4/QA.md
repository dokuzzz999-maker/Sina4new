# Verification report

Checked 29 September 2026.

- `npm run build`: passed. Astro diagnostics: zero errors, warnings, or hints. Static marketing output and Vercel server function generated successfully. The adapter reported that the local Node 24 runtime differs from its Node 22 function target; package engines explicitly require Node 22 for installation/deployment.
- `npm test`: eight tests passed, covering server security and delivery behavior with mocked services.
- Generated HTML: 28 pages checked for one H1, a description meta tag, and valid internal route/asset references; no broken references found.
- Fonts and visual assets are bundled locally. Client JavaScript separates the Earth/Three.js chunk from the shared site bundle.
- Company, contact, and legal-operation placeholders remain intentional and must be completed by the operator.

## Not verified here

Browser execution could not be completed in the available preview environment. Desktop/mobile visual QA, keyboard traversal, WebGL rendering, intro timing, View Transition lifecycle, real Turnstile challenges, and production delivery still require browser verification. The responsive and accessibility behaviors are implemented but are not certified by a browser accessibility audit.

Lighthouse 90+, WCAG AA conformance, and a 60fps mobile interaction target are not measured claims. Run Lighthouse and an accessibility audit on the configured Vercel deployment, and test representative mobile devices before public launch. No live Vercel deployment was made in this session.
